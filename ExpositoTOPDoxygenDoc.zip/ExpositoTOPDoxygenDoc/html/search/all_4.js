var searchData=
[
  ['initsolution_0',['initSolution',['../classmain_1_1java_1_1top_1_1_t_o_p_t_w_solution.html#aa2e4a505934ca0e4a2e1cb2c1c20c8ad',1,'main::java::top::TOPTWSolution']]]
];
